# HSE rules for this project: supplied by the user as project context

This file is intentionally empty of rules. The company/project HSE rules (for example the HSE-02 rulebook, method statements, penalty scheme, NCR lists) are added by the user to the project context and are read from there. Read that context first when analyzing photos; it is the highest-priority source (tag `[Dự án]`).

If the user pastes rules into this file, treat them as project context too.

## What the user can add (all optional)
- Rule documents with article numbers, so findings can cite them in "Căn cứ"
- Risk calibration (typical L x S scores by violation type), if it differs from the template's matrix
- Deadline policy by risk level, if it differs from 1-3 / 4-7 / 7+ days
- The list that defines major non-conformances (NCR nặng) and the penalty scheme
- Contractor list and abbreviations (NTC, BMW, ...), report-number sequence

## If nothing is available
Say so once, then ground findings on Vietnamese and international sources as described in SKILL.md, step 1. Do not invent project rule numbers.
