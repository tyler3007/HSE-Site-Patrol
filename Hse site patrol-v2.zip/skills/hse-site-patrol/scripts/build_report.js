#!/usr/bin/env node
// Usage: node build_report.js input.json output.xlsx [--contractor NAME]
// Fills assets/template.xlsx (HSE Site Patrol Report form) with patrol rows + violation photos.
// --contractor NAME keeps only items whose "con" equals NAME (one workbook per contractor).
const fs = require('fs'), path = require('path');
// exceljs is installed per session in the working dir (npm install exceljs@4.4.0), not next to this script.
const ExcelJS = (() => {
  for (const p of ['exceljs', path.join(process.cwd(), 'node_modules', 'exceljs'), '/home/claude/node_modules/exceljs']) {
    try { return require(p); } catch (e) { /* try next */ }
  }
  console.error('exceljs not found. Run: cd /home/claude && npm install exceljs@4.4.0'); process.exit(1);
})();

const FIRST = 7;                       // first data row in the template (row 7 holds a sample)
const FILL = { high: 'FFFF0000', med: 'FFFFFF00', low: 'FF00B050' };   // same colors as the header legend G2:G4
const NOTES_W = 76, LINE_PT = 14.3, MAX_PT = 409, IMG_W = 262;

function imgSize(buf) {
  if (buf[0] === 0x89 && buf[1] === 0x50) return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20), ext: 'png' };
  let i = 2; // JPEG: find a SOF marker
  while (i < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const m = buf[i + 1];
    if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7), ext: 'jpeg' };
    i += 2 + buf.readUInt16BE(i + 2);
  }
  throw new Error('Unsupported image (use JPEG or PNG)');
}

const levelOf = R => (R >= 15 ? 'high' : R >= 8 ? 'med' : 'low');
const lines = t => t.split('\n').reduce((n, p) => n + Math.max(1, Math.ceil(p.length / NOTES_W)), 0);

async function main() {
  const args = process.argv.slice(2);
  const ci = args.indexOf('--contractor');
  const only = ci >= 0 ? args.splice(ci, 2)[1] : null;
  const [inFile, outFile] = args;
  if (!inFile || !outFile) { console.error('usage: build_report.js input.json output.xlsx [--contractor NAME]'); process.exit(1); }
  const D = JSON.parse(fs.readFileSync(inFile, 'utf8'));
  const baseDir = path.dirname(path.resolve(inFile));
  let items = D.items || [];
  if (only) items = items.filter(x => x.con === only);
  if (!items.length) throw new Error('No items' + (only ? ` for contractor "${only}"` : ''));

  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(path.join(__dirname, '..', 'assets', 'template.xlsx'));
  const ws = wb.worksheets[0], cats = wb.worksheets[1];

  // Allowed categories come from the template's "Loại rủi ro" sheet (column A) so spelling always matches the dropdown.
  const catList = [];
  for (let r = 2; r <= cats.rowCount; r++) { const v = cats.getCell(r, 1).value; if (v) catList.push(String(v).trim()); }
  const catEnd = catList.length + 1;

  // Normalise risk: R = L x S when L and S are given.
  items.forEach((it, k) => {
    if (it.L && it.S) it.R = it.L * it.S;
    if (!it.R) throw new Error(`Item ${k + 1}: give L and S (1-5) or R`);
    if (!catList.includes(it.cat)) throw new Error(`Item ${k + 1}: category "${it.cat}" is not in the template list: ${catList.join(', ')}`);
  });

  ws.getCell('C2').value = D.project;
  ws.getCell('C3').value = (D.time ? D.time + ' Ngày ' : 'Ngày ') + D.date;
  ws.getCell('C4').value = D.who;

  // Snapshot the sample row's styles, then wipe the sample (values, photo).
  const clone = o => JSON.parse(JSON.stringify(o));
  const base = [1, 2, 3, 4, 5, 6, 7, 8, 9].map(c => clone(ws.getRow(FIRST).getCell(c).style));
  const riskStyle = lv => { const s = clone(base[4]); s.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: FILL[lv] } }; return s; };
  for (let c = 1; c <= 9; c++) ws.getRow(FIRST).getCell(c).value = null;
  ws._media = [];
  wb.media = [];

  const fb = { name: 'Times New Roman', size: 11, family: 1 };
  const H1 = 'Vấn đề (Mối nguy)';
  const H2 = 'Giải pháp (Loại bỏ, thay thế, biện pháp kiểm soát kỹ thuật, biện pháp kiểm soát hành chính, phương tiện bảo vệ cá nhân PPE): ';
  const counts = { high: 0, med: 0, low: 0 };

  items.forEach((it, i) => {
    const r = FIRST + i, row = ws.getRow(r);
    const problem = ': ' + it.problem + '\n', solution = (it.solution || '').replace(/\n*$/, '') + '\n';
    base.forEach((s, c) => { row.getCell(c + 1).style = s; });
    row.getCell(5).style = riskStyle(levelOf(it.R));
    counts[levelOf(it.R)]++;

    row.getCell(1).value = i + 1;
    row.getCell(2).value = it.pos || '';
    row.getCell(3).value = { richText: [
      { font: { ...fb, bold: true }, text: H1 }, { font: fb, text: problem },
      { font: { ...fb, bold: true }, text: H2 + '\n' },
      { font: { ...fb, bold: true, color: { argb: 'FF00B050' } }, text: solution }] };
    row.getCell(4).value = it.cat;
    row.getCell(5).value = it.R;
    row.getCell(6).value = '';
    row.getCell(7).value = '';          // contractor fills corrective action / photos here
    row.getCell(8).value = it.con || '';
    row.getCell(9).value = it.due || '';

    let img = null;
    if (it.image) {
      const p = path.resolve(baseDir, it.image);
      if (fs.existsSync(p)) { const buf = fs.readFileSync(p); img = { buf, ...imgSize(buf) }; }
      else console.warn(`Item ${i + 1}: image not found: ${p}`);
    }
    // Row height: enough for the text and for the photo at full column width.
    const textPt = (lines(H1 + problem) * LINE_PT + lines(H2) * LINE_PT + lines(solution) * LINE_PT + 12) * 1.08;
    const imgPt = img ? (IMG_W * img.h / img.w + 8) * 0.75 : 0;
    row.height = Math.min(MAX_PT, Math.max(textPt, imgPt, 90));

    if (img) {
      const rowPx = Math.round(row.height * 96 / 72), bh = rowPx - 8;
      const k = Math.min(IMG_W / img.w, bh / img.h), w = Math.round(img.w * k), h = Math.round(img.h * k);
      const id = wb.addImage({ buffer: img.buf, extension: img.ext });
      ws.addImage(id, { tl: { col: 5 + ((265 - w) / 2) / 265, row: r - 1 + ((rowPx - h) / 2) / rowPx }, ext: { width: w, height: h } });
    }
  });

  const last = FIRST + items.length - 1;
  ws.dataValidations.add(`D${FIRST}:D${last}`, { type: 'list', allowBlank: true, formulae: [`'${cats.name}'!$A$2:$A$${catEnd}`] });

  // Summary counts on "Loại rủi ro" (D2:D4). Template formulas cover E7:E207; widen if the report is longer.
  const rg = `'${ws.name}'!$E$7:$E$${Math.max(207, last + 100)}`;
  cats.getCell('D2').value = { formula: `COUNTIF(${rg},">=15")`, result: counts.high };
  cats.getCell('D3').value = { formula: `COUNTIFS(${rg},">=8",${rg},"<15")`, result: counts.med };
  cats.getCell('D4').value = { formula: `COUNTIFS(${rg},">=1",${rg},"<8")`, result: counts.low };
  cats.getCell('E2').value = { formula: 'SUM(D2:D4)', result: items.length };
  wb.calcProperties = { fullCalcOnLoad: true };

  await wb.xlsx.writeFile(outFile);
  console.log(`Saved ${outFile} - ${items.length} items (Cao ${counts.high}, Vừa ${counts.med}, Thấp ${counts.low})`);
}
main().catch(e => { console.error('ERROR:', e.message); process.exit(1); });
